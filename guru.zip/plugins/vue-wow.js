import Vue from 'vue'
import vWow from 'v-wow'

Vue.use(vWow);