import Vue from 'vue'
var VueScrollTo = require('vue-scrollto');

Vue.use(VueScrollTo)