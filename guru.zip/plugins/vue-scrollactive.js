import Vue from 'vue'
import VueScrollactive from 'vue-scrollactive';

Vue.use(VueScrollactive);