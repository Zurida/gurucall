<template>
    <i class="icon icon-fb">
        <svg width="29" height="28" viewBox="0 0 29 28" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="14.5" cy="14" r="14" fill="#3B5998"/>
            <path d="M16.3789 9.07422H17.7188V6.85938C17.4727 6.83203 16.707 6.75 15.7773 6.75C13.8906 6.75 12.5781 7.92578 12.5781 10.0586V12H10.5V14.4883H12.5781V20.75H15.1484V14.4883H17.1719L17.5 12H15.1484V10.3047C15.1484 9.56641 15.3672 9.07422 16.3789 9.07422Z"
                  fill="white"/>
        </svg>
    </i>
</template>

<script>
    export default {
        name: "icon-fb"
    }
</script>